@echo off
cd /d "%~dp0"
py -m pip install -r requirements.txt
if errorlevel 1 (
  echo Failed to install requirements. Check that Python and pip are installed.
  pause
  exit /b 1
)
py app.py
pause
