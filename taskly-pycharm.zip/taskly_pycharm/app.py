import os
import sqlite3
from functools import wraps
from datetime import datetime
from flask import Flask, g, render_template, request, redirect, url_for, session, flash, abort
from werkzeug.security import generate_password_hash, check_password_hash

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DB_PATH = os.path.join(BASE_DIR, "taskly.db")
app = Flask(__name__)
app.secret_key = os.environ.get("TASKLY_SECRET_KEY", "change-this-secret-key-before-public-hosting")
app.config.update(SESSION_COOKIE_HTTPONLY=True, SESSION_COOKIE_SAMESITE="Lax")

ADMIN_USERNAME = os.environ.get("TASKLY_ADMIN_USERNAME", "boford").strip().lower()
ADMIN_PASSWORD = os.environ.get("TASKLY_ADMIN_PASSWORD", "boford2007")

def db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(exception=None):
    connection = g.pop("db", None)
    if connection is not None:
        connection.close()

def init_db():
    with sqlite3.connect(DB_PATH) as conn:
        conn.execute("PRAGMA foreign_keys = ON")
        conn.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            username TEXT NOT NULL UNIQUE COLLATE NOCASE,
            email TEXT NOT NULL UNIQUE COLLATE NOCASE,
            password_hash TEXT NOT NULL,
            is_admin INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS tasks (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            title TEXT NOT NULL,
            description TEXT NOT NULL DEFAULT '',
            due_date TEXT NOT NULL DEFAULT '',
            priority TEXT NOT NULL DEFAULT 'Обычный',
            category TEXT NOT NULL DEFAULT 'Общее',
            completed INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );
        CREATE TABLE IF NOT EXISTS shares (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            sender_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            recipient_id INTEGER NOT NULL REFERENCES users(id) ON DELETE CASCADE,
            task_id INTEGER NOT NULL REFERENCES tasks(id) ON DELETE CASCADE,
            sent_at TEXT NOT NULL
        );
        """)
        row = conn.execute("SELECT id FROM users WHERE username = ?", (ADMIN_USERNAME,)).fetchone()
        if row is None:
            conn.execute(
                "INSERT INTO users (username,email,password_hash,is_admin,created_at) VALUES (?,?,?,?,?)",
                (ADMIN_USERNAME, "admin@taskly.local", generate_password_hash(ADMIN_PASSWORD), 1, datetime.now().isoformat(timespec="seconds"))
            )
        else:
            conn.execute("UPDATE users SET is_admin=1 WHERE username=?", (ADMIN_USERNAME,))
        conn.commit()

def current_user():
    user_id = session.get("user_id")
    if not user_id:
        return None
    return db().execute("SELECT id, username, email, is_admin FROM users WHERE id=?", (user_id,)).fetchone()

@app.context_processor
def inject_user():
    return {"current_user": current_user()}

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not current_user():
            flash("Сначала войдите в аккаунт.", "error")
            return redirect(url_for("login"))
        return view(*args, **kwargs)
    return wrapped

def admin_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        user = current_user()
        if not user or not user["is_admin"]:
            abort(403)
        return view(*args, **kwargs)
    return wrapped

@app.route("/")
def index():
    if current_user():
        return redirect(url_for("dashboard"))
    return redirect(url_for("login"))

@app.route("/register", methods=["GET", "POST"])
def register():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        username = request.form.get("username", "").strip()
        email = request.form.get("email", "").strip().lower()
        password = request.form.get("password", "")
        if len(username) < 3 or len(username) > 24 or not username.replace("_", "").isalnum():
            flash("Логин: 3–24 символа, только буквы, цифры и подчёркивание.", "error")
        elif "@" not in email or len(email) > 254:
            flash("Введите корректный email.", "error")
        elif len(password) < 8:
            flash("Пароль должен содержать минимум 8 символов.", "error")
        else:
            try:
                conn = db()
                conn.execute(
                    "INSERT INTO users (username,email,password_hash,is_admin,created_at) VALUES (?,?,?,?,?)",
                    (username, email, generate_password_hash(password), 0, datetime.now().isoformat(timespec="seconds"))
                )
                conn.commit()
                user = conn.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (username,)).fetchone()
                session.clear()
                session["user_id"] = user["id"]
                flash("Аккаунт создан. Добро пожаловать!", "success")
                return redirect(url_for("dashboard"))
            except sqlite3.IntegrityError:
                flash("Этот логин или email уже занят.", "error")
    return render_template("auth.html", mode="register")

@app.route("/login", methods=["GET", "POST"])
def login():
    if current_user():
        return redirect(url_for("dashboard"))
    if request.method == "POST":
        identity = request.form.get("identity", "").strip()
        password = request.form.get("password", "")
        user = db().execute(
            "SELECT * FROM users WHERE username=? COLLATE NOCASE OR email=? COLLATE NOCASE",
            (identity, identity)
        ).fetchone()
        if user and check_password_hash(user["password_hash"], password):
            session.clear()
            session["user_id"] = user["id"]
            flash("Вы вошли в аккаунт.", "success")
            return redirect(url_for("dashboard"))
        flash("Неверный логин/email или пароль.", "error")
    return render_template("auth.html", mode="login")

@app.route("/logout", methods=["POST"])
@login_required
def logout():
    session.clear()
    flash("Вы вышли из аккаунта.", "success")
    return redirect(url_for("login"))

@app.route("/dashboard", methods=["GET", "POST"])
@login_required
def dashboard():
    user = current_user()
    conn = db()
    if request.method == "POST":
        title = request.form.get("title", "").strip()
        if not title or len(title) > 160:
            flash("Название задачи обязательно (до 160 символов).", "error")
        else:
            conn.execute(
                "INSERT INTO tasks (user_id,title,description,due_date,priority,category,created_at) VALUES (?,?,?,?,?,?,?)",
                (user["id"], title, request.form.get("description","").strip()[:2000],
                 request.form.get("due_date","")[:10],
                 request.form.get("priority","Обычный") if request.form.get("priority") in ("Низкий","Обычный","Высокий") else "Обычный",
                 request.form.get("category","Общее").strip()[:40] or "Общее",
                 datetime.now().isoformat(timespec="seconds"))
            )
            conn.commit()
            flash("Задача добавлена.", "success")
            return redirect(url_for("dashboard"))
    tasks = conn.execute("SELECT * FROM tasks WHERE user_id=? ORDER BY completed ASC, id DESC", (user["id"],)).fetchall()
    shared = conn.execute("""
        SELECT s.sent_at, u.username AS sender, t.title, t.description, t.due_date, t.priority, t.category
        FROM shares s JOIN users u ON u.id=s.sender_id JOIN tasks t ON t.id=s.task_id
        WHERE s.recipient_id=? ORDER BY s.id DESC LIMIT 30
    """, (user["id"],)).fetchall()
    return render_template("dashboard.html", tasks=tasks, shared=shared)

@app.post("/task/<int:task_id>/toggle")
@login_required
def toggle_task(task_id):
    user = current_user()
    conn = db()
    task = conn.execute("SELECT id, completed FROM tasks WHERE id=? AND user_id=?", (task_id, user["id"])).fetchone()
    if not task:
        abort(404)
    conn.execute("UPDATE tasks SET completed=? WHERE id=? AND user_id=?", (0 if task["completed"] else 1, task_id, user["id"]))
    conn.commit()
    return redirect(url_for("dashboard"))

@app.post("/task/<int:task_id>/delete")
@login_required
def delete_task(task_id):
    user = current_user()
    conn = db()
    conn.execute("DELETE FROM tasks WHERE id=? AND user_id=?", (task_id, user["id"]))
    conn.commit()
    flash("Задача удалена.", "success")
    return redirect(url_for("dashboard"))

@app.post("/task/<int:task_id>/share")
@login_required
def share_task(task_id):
    user = current_user()
    conn = db()
    task = conn.execute("SELECT * FROM tasks WHERE id=? AND user_id=?", (task_id, user["id"])).fetchone()
    recipient_name = request.form.get("recipient", "").strip()
    recipient = conn.execute("SELECT id FROM users WHERE username=? COLLATE NOCASE", (recipient_name,)).fetchone()
    if not task:
        abort(404)
    if not recipient:
        flash("Пользователь с таким логином не найден.", "error")
    elif recipient["id"] == user["id"]:
        flash("Нельзя отправить задачу самому себе.", "error")
    else:
        conn.execute(
            "INSERT INTO tasks (user_id,title,description,due_date,priority,category,completed,created_at) VALUES (?,?,?,?,?,?,?,?)",
            (recipient["id"], task["title"], task["description"], task["due_date"], task["priority"], task["category"], 0, datetime.now().isoformat(timespec="seconds"))
        )
        conn.execute("INSERT INTO shares (sender_id,recipient_id,task_id,sent_at) VALUES (?,?,?,?)",
                     (user["id"], recipient["id"], task_id, datetime.now().isoformat(timespec="seconds")))
        conn.commit()
        flash(f"Копия задачи отправлена пользователю {recipient_name}.", "success")
    return redirect(url_for("dashboard"))

@app.route("/profile", methods=["GET", "POST"])
@login_required
def profile():
    user = current_user()
    if request.method == "POST":
        email = request.form.get("email", "").strip().lower()
        if "@" not in email or len(email) > 254:
            flash("Введите корректный email.", "error")
        else:
            try:
                db().execute("UPDATE users SET email=? WHERE id=?", (email, user["id"]))
                db().commit()
                flash("Профиль обновлён.", "success")
                return redirect(url_for("profile"))
            except sqlite3.IntegrityError:
                flash("Этот email уже используется.", "error")
    return render_template("profile.html", user=current_user())

@app.route("/admin")
@login_required
@admin_required
def admin():
    users = db().execute("""
        SELECT u.id,u.username,u.email,u.is_admin,u.created_at,COUNT(t.id) AS task_count
        FROM users u LEFT JOIN tasks t ON t.user_id=u.id
        GROUP BY u.id ORDER BY u.id
    """).fetchall()
    return render_template("admin.html", users=users)

@app.errorhandler(403)
def forbidden(error):
    return render_template("message.html", title="Доступ запрещён", message="Эта страница доступна только администратору."), 403

if __name__ == "__main__":
    init_db()
    print("\\nTaskly is running at:")
    print("  Local:   http://127.0.0.1:8080")
    print("  Network: http://172.16.130.66:8080 (if this is your computer's LAN IP)")
    print("Stop with Ctrl+C.\\n")
    app.run(host="0.0.0.0", port=8080, debug=False)
